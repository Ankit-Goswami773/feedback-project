package dal;
import java.sql.*;
public class Jcon {
	
	   private static int rollno;
	   private static String sname;
	   private static String branch;
	   private static int fees;
	   static Statement st;
	   static Connection conn;
	   private static String uname;
	   private static String upass;
	   private static String uid;
	   private static String uemail;
	   private static String umobno;
	   public static void connect() throws ClassNotFoundException,SQLException
	   {
		   Class.forName("com.mysql.jdbc.Driver");
		   conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
		   st = conn.createStatement();
	   }
	   public static int insert(int rollno,String sname,String branch, int fees) throws SQLException
	   {
		   int res=st.executeUpdate("insert into data(rollno,sname,branch,fees) values('"+rollno+"','"+sname+"','"+branch+"','"+fees+"')");
	       return res;
	   }
	   public static int update(int rollno,String sname,String branch,int fess) throws SQLException
	   {
		int res=st.executeUpdate("update data set sname='"+sname+"',branch='"+branch+"',fees='"+fees+"' where rollno='"+rollno+"'");   
	     return res;
	   }
	   public static int delete(int rollno) throws SQLException
	   {
		 int res=st.executeUpdate("delete from data where rollno='"+rollno+"'");  
	     return res;
	   }
	   
	   public static ResultSet showData() throws SQLException
	   {
		ResultSet res= st.executeQuery("select * from data"); 
	     return res;
	   }
	   public static ResultSet findData(int rollno) throws SQLException
	   {
		ResultSet res=st.executeQuery("select * from data where rollno='"+rollno+"'");   
	    return res;
	   }
	   public static int regInsert(String uid,String upass,String uemail,String umobno) throws SQLException
	   {
		int res=st.executeUpdate("insert into user_reg(uid,upass,uemail,umobno)values('"+uid+"','"+upass+"','"+uemail+"','"+umobno+"') ");   
	    return res;
	   }
	   public static ResultSet ulogin(String uid,String upass) throws SQLException
	   {
		ResultSet res=st.executeQuery("select * from user_reg where uid='"+uid+"'and upass='"+upass+"'");   
	    return res;
	   }
	   public static int feedInsert(String fname,String fedto,String rt) throws SQLException
	   {
		  int res=st.executeUpdate("insert into feed(fname,fedto,rating) values('"+fname+"','"+fedto+"','"+rt+"')");
	      return res;
	   }
	   public static boolean chechFeed(String fname,String fedto) throws SQLException
	   {
		 ResultSet res=st.executeQuery("select * from feed where fname='"+fname+"' and fedto='"+fedto+"'");
		   return res.next();
	   }
	   public static int adfac(String fname,String fpass,String subject) throws SQLException
	   {
		 int res=st.executeUpdate("insert into adfac(fname,fpass,subject) values('"+fname+"','"+fpass+"','"+subject+"')");
		 return res;
	   }
	   public static  ResultSet showFac() throws SQLException
	   {
		ResultSet res=st.executeQuery("select * from adfac");
		 return res;
	   }
	   public static ResultSet showfeedback() throws SQLException
	   {
		  
		   ResultSet res = st.executeQuery("select * from feed ");
		   return res;
	   }
	   public static ResultSet showfeedback(String  uid) throws SQLException
	   {
		  
		   ResultSet res = st.executeQuery("select * from feed where fname='"+uid+"'");
		   return res;
	   }
	   public static ResultSet findfeedback(int  uid) throws SQLException
	   {
		  
		   ResultSet res = st.executeQuery("select * from feed where id='"+uid+"'");
		   return res;
	   }
	   public static void close() throws SQLException
	   {
		   conn.close();
	   }
	   public static ResultSet login(String uname,String upass) throws SQLException
	   {
		ResultSet res=st.executeQuery("select * from login where uname='"+uname+"'and upass='"+upass+"'");   
	    return res;
	   }
	   public static ResultSet flogin(String fname,String fpass) throws SQLException
	   {
		ResultSet res=st.executeQuery("select * from adfac where fname='"+fname+"'and fpass='"+fpass+"'");   
	    return res;
	   }
	   public static int feedreply(String fr,String fedto,String reply) throws SQLException
	   {
		  int res=st.executeUpdate("insert into feedrply(fr,fedto,reply) values('"+fr+"','"+fedto+"','"+reply+"')");
	      return res;
	   }
	  
	   public static ResultSet viewReply() throws SQLException
	   {
		   ResultSet res=st.executeQuery("select * from feedrply");
		   return res;
	   }
	   public static ResultSet viewReply(String uid) throws SQLException
	   {
		 ResultSet res=st.executeQuery("select * from feedrply where fedto='"+uid+"'");
		   return res;
	   }
	  
	   public static ResultSet searchData(String s) throws SQLException
	   {   
		   String search=s+"%";
		   
		   ResultSet res=st.executeQuery("select * from data where sname like '"+search+"'");
		   return res;
	   }
	   public static boolean checkemail(String email) throws SQLException
	   {
		 ResultSet res=st.executeQuery("select * from user_reg where uemail='"+email+"'");
		   return res.next();
	   }
}
